/** @type {import('next').NextConfig} */
const nextConfig = {
    poweredByHeader: false,
};

module.exports = nextConfig;
